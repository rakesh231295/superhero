//----------------------------------------------------------------
//Favourite Superhero Page App Initialization
favouriteSuperheroPage.initialize();
//----------------------------------------------------------------
